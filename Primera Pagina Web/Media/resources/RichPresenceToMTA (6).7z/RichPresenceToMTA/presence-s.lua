local application = {
    id = "1257456575031939092",
    state = "Jugadores Conectados:",
    max_slots = tonumber(getServerConfigSetting("maxplayers")),
    logo = "",
    logo_name = "Ciudad Latina RP",
    details = "",

    buttons = {
        [1] = {
            use = true,
            name = "Discord",
            link = "https://discord.gg/rWkkkdvSM6"
        },

        [2] = {
            use = true,
            name = "Conectar",
            link = "mtasa://161.129.181.10:22014"
        }
    }
};

addEventHandler("onPlayerResourceStart", root,
    function(theResource)
        if (theResource == resource) then
            -- Obtén el nombre del usuario
            local nombreUsuario = getPlayerName(source)
            
            -- Concatena el nombre del usuario a la cadena existente en details
            
            -- Envía la información actualizada al cliente
            triggerClientEvent(source, "addPlayerRichPresence", source, application);
        end
    end
);
