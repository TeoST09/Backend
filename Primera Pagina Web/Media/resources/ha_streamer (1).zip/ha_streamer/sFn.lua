local armorr = { }
local time = getRealTime()
local horas = time.hour
local minutos = time.minute
local segundos = time.second


tag = "Streamer" 



function LANCER (player)    
    local veiculo = createVehicle (429, Vector3 (getElementPosition (player)))
    warpPedIntoVehicle (player, veiculo )
    triggerClientEvent(source, "Notify", source, "sucesso", "Você pegou um LANCER com sucesso", "Você pegou um LANCER com sucesso", 10)
    triggerEvent("zx-LogDiscord", source, source, '```Pegou 1x LANCER``` Name : **'..getPlayerName(source)..'** \n ID : **'..getElementData(source,'ID')..'**', 1)
end
addEvent("LANCER", true)
addEventHandler("LANCER", getRootElement(), LANCER)

function H2R (player)
    local veiculo = createVehicle (521, Vector3 (getElementPosition (player)))
    warpPedIntoVehicle (player, veiculo )
    triggerClientEvent(source, "Notify", source, "sucesso", "Você pegou uma H2R com sucesso", "Você pegou uma H2R com sucesso ", 10)
    triggerEvent("zx-LogDiscord", source, source, '```Pegou 1x H2R``` Name : **'..getPlayerName(source)..'** \n ID : **'..getElementData(source,'ID')..'**', 1)
end
addEvent("H2R", true)
addEventHandler("H2R", getRootElement(), H2R)

function KITPVP ()
    giveWeapon ( source, 23, 200 )
    giveWeapon ( source, 30, 200 )
    exports["[HS]Inventory_system_2"]:giveItem(source , "ak-47", 1)
    exports["[HS]Inventory_system_2"]:giveItem(source , "556", 5)
    exports["[HS]Inventory_system_2"]:giveItem(source , "9mm", 5)
    exports["[HS]Inventory_system_2"]:giveItem(source , "colt", 5)
	exports["[HS]Inventory_system_2"]:giveItem(source , "bandage", 500)
    triggerClientEvent(source, "Notify", source, "sucesso", "Você pegou um KITPVP com sucesso", "Você pegou um KITPVP com sucesso ", 10)
    triggerEvent("zx-LogDiscord", source, source, '```Pegou 1x KITPVP``` Name : **'..getPlayerName(source)..'** \n ID : **'..getElementData(source,'ID')..'**', 1)
end
addEvent("KITPVP", true)
addEventHandler("KITPVP", getRootElement(), KITPVP)


--[[
 ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
 ███╗   ███╗████████╗ █████╗    ███████╗ █████╗     ███╗   ███╗ ██████╗ ██████╗ ███████╗█
 ████╗ ████║╚══██╔══╝██╔══██╗██╗██╔════╝██╔══██╗    ████╗ ████║██╔═══██╗██╔══██╗██╔════╝█
 ██╔████╔██║   ██║   ███████║╚═╝███████╗███████║    ██╔████╔██║██║   ██║██║  ██║███████╗█
 ██║╚██╔╝██║   ██║   ██╔══██║██╗╚════██║██╔══██║    ██║╚██╔╝██║██║   ██║██║  ██║╚════██║█
 ██║ ╚═╝ ██║   ██║   ██║  ██║╚═╝███████║██║  ██║    ██║ ╚═╝ ██║╚██████╔╝██████╔╝███████║█
 █╚═╝     ╚═╝   ╚═╝   ╚═╝  ╚═╝   ╚══════╝╚═╝  ╚═╝    ╚═╝     ╚═╝ ╚═════╝ ╚═════╝ ╚══════█
 █                                                                                      █
 █                ┌───────────────────────────────────────────────────┐                 █
 █                ┤MAIS DE 500 MODS DESCOMPILADOS COM DOWNLOAD DIRETO!┤                 █
 █                └───────────────────────────────────────────────────┘                 █
 █                   ┌─────────────────────────────────────────────┐                    █
 █                   ┤ A MAIOR COMUNIDADE DE MODS DO MTA BRASIL 🥇 ┤                    █
 █                   └─────────────────────────────────────────────┘                    █
 █                          ┌───────────────────────────────┐                           █
 █                          ┤  LINK DE CONVITE PERMANENTE:  ┤                           █
 █                          ┤ https://discord.gg/KXV2GHtJtg ┤                           █
 █                          ┤ https://discord.gg/KXV2GHtJtg ┤                           █
 █                          ┤ https://discord.gg/KXV2GHtJtg	┤                           █
 █                          └───────────────────────────────┘                           █
 █ ┌────────────────────────────────────────┐                                           █
 ├≡┤ Canais que postamos mods todos os dias │                                           █
 █ └────────────────────────────────────────┘                                           █
 █ ┤ Veiculos-Low-Poly                                                                  █
 █ ┤ Armas-Exclusivas                                                                   █
 █ ┤ Skins-Exclusivas                                                                   █
 █ ┤ Concessionárias                                                                    █
 █ ┤ Modelagens                                                                         █
 █ ┤ Sons-Armas                                                                         █
 █ ┤ Exclusivos - Mods Exclusivos                                                       █
 █ ┤ Interiores                                                                         █
 █ ┤ Animações                                                                          █
 █ ┤ Resources                                                                          █
 █ ┤ ls-full-br - Uma conversão de mapas para deixar los santos brasileira              █
 █ ┤ Calçadas                                                                           █
 █ ┤ Mapas                                                                              █
 █ ┤ Radar                                                                              █
 █ ┤ Huds                                                                               █
 █                                                                                      █
 ██▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄██
 ]]