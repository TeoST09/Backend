local screenW,screenH = guiGetScreenSize()
local resW, resH = 1366,768
local x, y = (screenW/resW), (screenH/resH)

local fnx = false
function FnDark ()
        dxDrawImage(screenW * 0.1631, screenH * 0.1800, screenW * 0.6884, screenH * 0.6635, 'files/Fundo.png', 0, 0, 0, tocolor(255,255,255,255), false)                                           
------------------------------------------------------------------------------------------------------------    
        --roundedRectangle(screenW * 0.7050, screenH * 0.2650, screenW * 0.1223, screenH * 0.1500, tocolor(61, 61, 61, 230), false) ---------- Lancer
        if isMouseInPosition(screenW * 0.7050, screenH * 0.2650, screenW * 0.1223, screenH * 0.1500, screenH * 0.0339) then
        roundedRectangle(screenW * 0.7050, screenH * 0.2650, screenW * 0.1223, screenH * 0.1500, tocolor(0, 114, 255, 50), false) ---------- Lancer
        end
        --roundedRectangle(screenW * 0.7050, screenH * 0.4525, screenW * 0.1223, screenH * 0.1500, tocolor(61, 61, 61, 230), false) ---------- H2R
        if isMouseInPosition(screenW * 0.7050, screenH * 0.4525, screenW * 0.1223, screenH * 0.1500, screenH * 0.0339) then
        roundedRectangle(screenW * 0.7050, screenH * 0.4525, screenW * 0.1223, screenH * 0.1500, tocolor(0, 114, 255, 50), false) ---------- H2R
        end
        --roundedRectangle(screenW * 0.7050, screenH * 0.6405, screenW * 0.1223, screenH * 0.1500, tocolor(61, 61, 61, 230), false) ---------- KITPVP
        if isMouseInPosition(screenW * 0.7050, screenH * 0.6405, screenW * 0.1223, screenH * 0.1500, screenH * 0.0339) then
        roundedRectangle(screenW * 0.7050, screenH * 0.6405, screenW * 0.1223, screenH * 0.1500, tocolor(0, 114, 255, 50), false) ---------- KITPVP
        end
end


function streamer ()
    if fnx == false then
    addEventHandler ("onClientRender", root, FnDark)
    showCursor (true)
    fnx = true
    end
    end
    addEvent ("streamer", true)
    addEventHandler ("streamer", root, streamer)

addCommandHandler("streamer", streamer)
bindKey("backspace", "down", function()
    if fnx == true then
        removeEventHandler("onClientRender", getRootElement(), FnDark)
        fnx = false
        showCursor(false)
    end
end)

function dxDrawRectangleBorde(x, y, w, h, borderColor, bgColor, postGUI)
    if (x and y and w and h) then
        if (not borderColor) then
            borderColor = tocolor(0, 0, 0, 200)
        end

        if (not bgColor) then
            bgColor = borderColor
        end

        dxDrawRectangle(x, y, w, h, bgColor, postGUI)

        dxDrawRectangle(x + 2, y - 1, w - 4, 1, borderColor, postGUI) -- top
        dxDrawRectangle(x + 2, y + h, w - 4, 1, borderColor, postGUI) -- bottom
        dxDrawRectangle(x - 1, y + 2, 1, h - 4, borderColor, postGUI) -- left
        dxDrawRectangle(x + w, y + 2, 1, h - 4, borderColor, postGUI) -- right
    end
end

function roundedRectangle(x, y, w, h, borderColor, bgColor, postGUI)
	if (x and y and w and h) then
		if (not borderColor) then
			borderColor = tocolor(0, 255, 0, 200);
		end
		
		if (not bgColor) then
			bgColor = borderColor;
		end
		
		--> Background
		dxDrawRectangle(x, y, w, h, bgColor, postGUI);
		
		--> Border
		dxDrawRectangle(x + 2, y - 1, w - 4, 1, borderColor, postGUI); -- top
		dxDrawRectangle(x + 2, y + h, w - 4, 1, borderColor, postGUI); -- bottom
		dxDrawRectangle(x - 1, y + 2, 1, h - 4, borderColor, postGUI); -- left
		dxDrawRectangle(x + w, y + 2, 1, h - 4, borderColor, postGUI); -- right
	end
end

addEventHandler("onClientClick", getRootElement(), function(button, state)
        if button=="left" and state=="down" then
           if fnx == true then
            if isMouseInPosition(screenW * 0.7050, screenH * 0.2650, screenW * 0.1223, screenH * 0.1500) then
            triggerServerEvent("LANCER", localPlayer, localPlayer)
            end
        end
    end
end)


addEventHandler("onClientClick", getRootElement(), function(button, state)
    if button=="left" and state=="down" then
       if fnx == true then
        if isMouseInPosition(screenW * 0.7050, screenH * 0.4525, screenW * 0.1223, screenH * 0.1500) then
        triggerServerEvent("H2R", localPlayer, localPlayer)
        end
    end
end
end)


addEventHandler("onClientClick", getRootElement(), function(button, state)
    if button=="left" and state=="down" then
       if fnx == true then
        if isMouseInPosition(screenW * 0.7050, screenH * 0.6405, screenW * 0.1223, screenH * 0.1500) then
        triggerServerEvent("KITPVP", localPlayer)
        end
    end
end
end)



-----------------UTILS-----------------


function isMouseInPosition ( x, y, width, height )
	if ( not isCursorShowing( ) ) then
		return false
	end
	local sx, sy = guiGetScreenSize ( )
	local cx, cy = getCursorPosition ( )
	local cx, cy = ( cx * sx ), ( cy * sy )
	
	return ( ( cx >= x and cx <= x + width ) and ( cy >= y and cy <= y + height ) )
end

--[[
 ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
 ███╗   ███╗████████╗ █████╗    ███████╗ █████╗     ███╗   ███╗ ██████╗ ██████╗ ███████╗█
 ████╗ ████║╚══██╔══╝██╔══██╗██╗██╔════╝██╔══██╗    ████╗ ████║██╔═══██╗██╔══██╗██╔════╝█
 ██╔████╔██║   ██║   ███████║╚═╝███████╗███████║    ██╔████╔██║██║   ██║██║  ██║███████╗█
 ██║╚██╔╝██║   ██║   ██╔══██║██╗╚════██║██╔══██║    ██║╚██╔╝██║██║   ██║██║  ██║╚════██║█
 ██║ ╚═╝ ██║   ██║   ██║  ██║╚═╝███████║██║  ██║    ██║ ╚═╝ ██║╚██████╔╝██████╔╝███████║█
 █╚═╝     ╚═╝   ╚═╝   ╚═╝  ╚═╝   ╚══════╝╚═╝  ╚═╝    ╚═╝     ╚═╝ ╚═════╝ ╚═════╝ ╚══════█
 █                                                                                      █
 █                ┌───────────────────────────────────────────────────┐                 █
 █                ┤MAIS DE 500 MODS DESCOMPILADOS COM DOWNLOAD DIRETO!┤                 █
 █                └───────────────────────────────────────────────────┘                 █
 █                   ┌─────────────────────────────────────────────┐                    █
 █                   ┤ A MAIOR COMUNIDADE DE MODS DO MTA BRASIL 🥇 ┤                    █
 █                   └─────────────────────────────────────────────┘                    █
 █                          ┌───────────────────────────────┐                           █
 █                          ┤  LINK DE CONVITE PERMANENTE:  ┤                           █
 █                          ┤ https://discord.gg/KXV2GHtJtg ┤                           █
 █                          ┤ https://discord.gg/KXV2GHtJtg ┤                           █
 █                          ┤ https://discord.gg/KXV2GHtJtg	┤                           █
 █                          └───────────────────────────────┘                           █
 █ ┌────────────────────────────────────────┐                                           █
 ├≡┤ Canais que postamos mods todos os dias │                                           █
 █ └────────────────────────────────────────┘                                           █
 █ ┤ Veiculos-Low-Poly                                                                  █
 █ ┤ Armas-Exclusivas                                                                   █
 █ ┤ Skins-Exclusivas                                                                   █
 █ ┤ Concessionárias                                                                    █
 █ ┤ Modelagens                                                                         █
 █ ┤ Sons-Armas                                                                         █
 █ ┤ Exclusivos - Mods Exclusivos                                                       █
 █ ┤ Interiores                                                                         █
 █ ┤ Animações                                                                          █
 █ ┤ Resources                                                                          █
 █ ┤ ls-full-br - Uma conversão de mapas para deixar los santos brasileira              █
 █ ┤ Calçadas                                                                           █
 █ ┤ Mapas                                                                              █
 █ ┤ Radar                                                                              █
 █ ┤ Huds                                                                               █
 █                                                                                      █
 ██▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄██
 ]]